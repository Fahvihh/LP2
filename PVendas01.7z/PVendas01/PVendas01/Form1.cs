﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PVendas01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_verificar_Click(object sender, EventArgs e)
        {
            Double[,] Matriz = new double[3,4];
            string valor;
            double numero;
            double Soma=0;
            string texto;
            string texto2;
            string texto3;
            double TotalGeral=0;
            for (int i = 0; i < 3; i++){
                for (int j = 0; j < 4; j++)
                {
                    valor = Interaction.InputBox($"Digite o valor recebido da semana {j+1} do mês {i+1}", "Entrada de dados");
                    if (double.TryParse(valor, out numero) && (numero>=0)){
                        Matriz[i, j] = numero;
                        Soma += numero;
                        numero = 0;
                        texto = $"Total do mês: {i + 1} Semana {j + 1}: {Matriz[i, j].ToString("F2")}";
                        lbox.Items.Add(texto);
                    } 
                }
                string teste;
                texto2 = $">> Total mês: {Soma.ToString("F2")}";
                lbox.Items.Add(texto2);
                TotalGeral += Soma;
                Soma = 0;
            }
            texto3 = $">> Total Geral: {TotalGeral.ToString("F2")}";
            lbox.Items.Add(texto3);
            

        }

        private void btn_limpar_Click(object sender, EventArgs e)
        {
            lbox.Items.Clear();
        }
    }
}
