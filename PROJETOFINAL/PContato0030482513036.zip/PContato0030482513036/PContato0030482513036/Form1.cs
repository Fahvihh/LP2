﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Security.Cryptography.X509Certificates;

namespace PContato0030482513036
{
    public partial class frm_principal : Form
    {
        public static SqlConnection conexao;
        public frm_principal()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void frm_principal_Load(object sender, EventArgs e)
        {
            try
            {
                conexao = new SqlConnection("Data Source=Joseph\\SQLEXPRESS;Initial Catalog=BD;Integrated Security=True");
                conexao.Open();
            }
            catch (SqlException ex)
            {
                MessageBox.Show("Erro de banco de dados =/" + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Outros erros =/" + ex.Message);
            }
        }

        private void cadastroContatosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<frmContato>().Count()> 0){

                Application.OpenForms["frmContato"].BringToFront();

            } else
            {
                frmContato FRMC = new frmContato();
                FRMC.MdiParent = this;
                FRMC.WindowState = FormWindowState.Maximized;
                FRMC.Show();
            }
        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<sobre>().Count() > 0)
            {

                Application.OpenForms["sobre"].BringToFront();

            }
            else
            {
                sobre SBR = new sobre();
                SBR.MdiParent = this;
                SBR.WindowState = FormWindowState.Maximized;
                SBR.Show();
            }
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
